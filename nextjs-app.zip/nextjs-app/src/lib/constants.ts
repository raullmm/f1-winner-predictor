import { env } from "../env.mjs";

export const NEXT_PUBLIC_API_URL = env.NEXT_PUBLIC_API_URL || 'http://localhost:3000/api';