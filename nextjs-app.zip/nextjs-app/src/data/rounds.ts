/**
 *  Calendario 2025 provisional.
 *  Ajusta nombres/orden si la FIA publica cambios.
 */
export const roundsCurrent = [
  "Bahrain International Circuit",
  "Jeddah Corniche Circuit",
  "Albert Park Circuit",
  "Suzuka Circuit",
  "Shanghai International Circuit",
  "Miami International Autodrome",
  "Autodromo Enzo e Dino Ferrari (Imola)",
  "Circuit de Barcelona-Catalunya",
  "Circuit Gilles-Villeneuve",
  "Red Bull Ring",
  "Silverstone Circuit",
  "Hungaroring",
  "Circuit de Spa-Francorchamps",
  "Circuit Zandvoort",
  "Autodromo Nazionale Monza",
  "Baku City Circuit",
  "Marina Bay Street Circuit",
  "Circuit of the Americas",
  "Autódromo Hermanos Rodríguez",
  "Autódromo José Carlos Pace (Interlagos)",
  "Las Vegas Street Circuit",
  "Lusail International Circuit",
  "Yas Marina Circuit",
];
